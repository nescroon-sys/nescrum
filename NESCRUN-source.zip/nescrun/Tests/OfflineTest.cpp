// Prueba offline: procesa una "voz" sintetica desafinada y verifica afinacion,
// picos, NaN, latencia y CPU. Escribe WAVs de antes/despues.
#include "../Source/PluginProcessor.h"
#include <juce_audio_formats/juce_audio_formats.h>
#include <chrono>

static float yinPitch (const std::vector<float>& x, int start, double sr)
{
    const int W = 2048, tmax = (int) (sr / 70), tmin = (int) (sr / 1000);
    std::vector<float> d ((size_t) tmax + 1, 0.f);
    float run = 0.f; d[0] = 1.f;
    for (int t = 1; t <= tmax; ++t)
    {
        float s = 0.f;
        for (int j = 0; j < W; ++j) { const float e = x[(size_t) (start + j)] - x[(size_t) (start + j + t)]; s += e * e; }
        run += s; d[(size_t) t] = s * t / run;
    }
    for (int t = tmin; t < tmax; ++t)
        if (d[(size_t) t] < 0.12f) { while (t + 1 < tmax && d[(size_t) t + 1] < d[(size_t) t]) ++t; const float a=d[(size_t)t-1],b=d[(size_t)t],c=d[(size_t)t+1]; const float o=0.5f*(a-c)/(a+c-2*b); return (float) (sr / (t + o)); }
    return 0.f;
}

static void writeWav (const juce::File& f, const juce::AudioBuffer<float>& b, double sr)
{
    f.deleteFile();
    juce::WavAudioFormat wav;
    std::unique_ptr<juce::AudioFormatWriter> w (wav.createWriterFor (new juce::FileOutputStream (f), sr, (unsigned) b.getNumChannels(), 24, {}, 0));
    w->writeFromAudioSampleBuffer (b, 0, b.getNumSamples());
}

int main (int argc, char** argv)
{
    juce::ScopedJuceInitialiser_GUI init;
    if (argc > 2) { for(double srr: {44100.0,48000.0}) for (double f0 : {110.0, 220.0, 440.0}) {
        nescrun::PitchCorrector p; p.prepare(srr); p.setParams(1,0,0,30,1,0.6f);
        double ph=0, sum=0; int c=0;
        for(int i=0;i<srr*2;i++){ ph+=f0/srr; if(ph>1)ph-=1; float s=0; for(int h=1;h*f0<8000;h++) s+=(float)(std::sin(2*M_PI*h*ph)/h); p.processSample(0.1f*s);
          if(i>srr && i%256==0){ float m=p.detectedMidi.load(); if(m>0){sum+=m;c++;}}}
        double e=69+12*std::log2(f0/440); std::printf("sr %g f %g: det err %+.2f ct\n",srr,f0,(sum/c-e)*100);} return 0; }
    const double sr = 48000.0; const int block = 512;
    const int len = (int) (sr * 6);
    const juce::String outDir = argc > 1 ? argv[1] : "/tmp";

    // voz sintetica: diente de sierra limitado en banda (armonicos), formantes, vibrato, notas desafinadas
    juce::AudioBuffer<float> in (2, len);
    const float notes[3] = { 223.5f, 251.f, 286.f }; // A3 +27ct, B3 +23ct, D4 -11ct  (escala C mayor contiene A, B, D)
    double ph = 0.0; juce::Random rng (7);
    juce::dsp::IIR::Filter<float> f1, f2;
    f1.coefficients = juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, 700, 2.0, 4.0);
    f2.coefficients = juce::dsp::IIR::Coefficients<float>::makePeakFilter (sr, 2500, 2.0, 3.0);
    for (int i = 0; i < len; ++i)
    {
        const double t = i / sr;
        const int seg = std::min (2, (int) (t / 2.0));
        const double f0 = notes[seg] * (1.0 + 0.004 * std::sin (2 * juce::MathConstants<double>::pi * 5.5 * t));
        ph += f0 / sr; if (ph > 1.0) ph -= 1.0;
        float s = 0.f;
        for (int h = 1; h * f0 < 8000.0; ++h) s += (float) (std::sin (2 * juce::MathConstants<double>::pi * h * ph) / h);
        const double segT = t - seg * 2.0;
        const float env = (float) std::min (1.0, std::min (segT / 0.05, (2.0 - segT) / 0.08));
        s = f2.processSample (f1.processSample (s)) * 0.12f * std::max (0.f, env) + (rng.nextFloat() - 0.5f) * 0.002f;
        in.setSample (0, i, s); in.setSample (1, i, s);
    }

    NescrunProcessor proc;
    proc.setPlayConfigDetails (2, 2, sr, block);
    proc.setCurrentProgram (0);
    auto set = [&] (const char* id, float v) { auto* p = proc.apvts.getParameter (id); p->setValueNotifyingHost (p->convertTo0to1 (v)); };
    set ("tune_mode", 1); set ("tune_key", 0); set ("tune_scale", 1); set ("tune_speed", 30); set ("tune_amount", 100); set ("tune_human", 60);
    if (std::getenv ("ONLYTUNE")) for (auto id : { "clean_on", "comp_on", "eq_on", "color_on", "mod_on", "delay_on", "rev_on", "lim_on" }) set (id, 0.f);
    if (std::getenv ("HUM0")) set ("tune_human", 0.f);
    proc.prepareToPlay (sr, block);
    { int bad = 0; for (auto& pr : nescrun::factoryPresets()) for (auto& [id, v] : pr.values) if (proc.apvts.getParameter (id) == nullptr) { std::printf ("BAD ID %s in %s\n", id, pr.name); ++bad; }
      std::printf ("presets: %d, bad ids: %d\n", (int) nescrun::factoryPresets().size(), bad);
      for (int i = 0; i < proc.getNumPrograms(); ++i) proc.setCurrentProgram (i); proc.setCurrentProgram (0); }
    std::printf ("latency: %d samples (%.1f ms)\n", proc.getLatencySamples(), proc.getLatencySamples() * 1000.0 / sr);

    juce::AudioBuffer<float> out (in);
    juce::MidiBuffer midi;
    auto t0 = std::chrono::high_resolution_clock::now();
    for (int s = 0; s < len; s += block)
    {
        const int n = std::min (block, len - s);
        juce::AudioBuffer<float> view (out.getArrayOfWritePointers(), 2, s, n);
        proc.processBlock (view, midi);
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    const double secs = std::chrono::duration<double> (t1 - t0).count();
    std::printf ("CPU: %.3f s for %.1f s audio (%.1f%% of one core)\n", secs, len / sr, 100.0 * secs / (len / sr));

    bool nan = false; float pk = 0.f;
    for (int i = 0; i < len; ++i) { const float v = out.getSample (0, i); if (! std::isfinite (v)) nan = true; pk = std::max (pk, std::abs (v)); }
    std::printf ("NaN: %s  peak: %.2f dBFS\n", nan ? "YES" : "no", juce::Decibels::gainToDecibels (pk));

    // pitch antes y despues (compensando latencia), mitad de cada nota
    const int lat = proc.getLatencySamples();
    std::vector<float> xi ((size_t) len), xo ((size_t) len);
    for (int i = 0; i < len; ++i) { xi[(size_t) i] = in.getSample (0, i); xo[(size_t) i] = out.getSample (0, i); }
    const float targets[3] = { 220.f, 246.94f, 293.66f };
    for (int k = 0; k < 3; ++k)
    {
        const int st = (int) ((k * 2.0 + 1.0) * sr);
        const float a = yinPitch (xi, st, sr), b = yinPitch (xo, st + lat, sr);
        std::printf ("note %d: in %.1f Hz (%+.0f ct)  ->  out %.1f Hz (%+.0f ct vs target)\n", k, a,
                     1200 * std::log2 (a / targets[k]), b, 1200 * std::log2 (b / targets[k]));
    }
    writeWav (juce::File (outDir + "/nescrun_before.wav"), in, sr);
    writeWav (juce::File (outDir + "/nescrun_after.wav"), out, sr);

    // prueba de latencia: todo apagado salvo el camino, impulso
    NescrunProcessor p2; p2.setPlayConfigDetails (2, 2, sr, block);
    for (auto id : { "clean_on", "comp_on", "eq_on", "color_on", "mod_on", "delay_on", "rev_on", "lim_on" })
    { auto* p = p2.apvts.getParameter (id); p->setValueNotifyingHost (0.f); }
    { auto* p = p2.apvts.getParameter ("tune_mode"); p->setValueNotifyingHost (0.f); }
    { auto* p = p2.apvts.getParameter ("width"); p->setValueNotifyingHost (p->convertTo0to1 (100.f)); }
    p2.prepareToPlay (sr, block);
    juce::AudioBuffer<float> imp (2, 8192); imp.clear(); imp.setSample (0, 100, 0.5f); imp.setSample (1, 100, 0.5f);
    for (int s = 0; s < 8192; s += block) { juce::AudioBuffer<float> v (imp.getArrayOfWritePointers(), 2, s, block); p2.processBlock (v, midi); }
    int pos = 0; float mx = 0.f;
    for (int i = 0; i < 8192; ++i) if (std::abs (imp.getSample (0, i)) > mx) { mx = std::abs (imp.getSample (0, i)); pos = i; }
    std::printf ("impulse peak at %d (expected %d), value %.3f\n", pos, 100 + p2.getLatencySamples(), mx);

    // editor: instanciar y renderizar a PNG
    {
        std::unique_ptr<juce::AudioProcessorEditor> ed (proc.createEditor());
        ed->setSize (1200, 720);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.5f);
        juce::PNGImageFormat png; juce::File f (outDir + "/nescrun_ui.png"); f.deleteFile();
        juce::FileOutputStream os (f); png.writeImageToStream (img, os);
        std::printf ("UI snapshot written\n");
    }
    return 0;
}
